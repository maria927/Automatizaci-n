package com.accenture;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.imageio.ImageIO;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;
import org.apache.commons.mail.SimpleEmail;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.SendKeysAction;

import jxl.Workbook;
import jxl.read.biff.BiffException;

public class FacebookEjemplo {
	private static final int KeyEvent = 0;
	
	static String dato3;
	static String dato1;
	static List<WebElement> names;
	static ArrayList<String> ArraySi = new ArrayList<String>();
	static ArrayList<String> ArrayNo = new ArrayList<String>();
	
	
	public static void main(String[] args) throws Exception 
	{
		
		 
		String exePath = "C:/Users/isabel.alzate/chromedriver_win32/chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);  
		
		
		   WebDriver driver = new ChromeDriver();
		   driver.get("https://www.facebook.com");
	
		
		   File src=new File("C:\\Users\\isabel.alzate\\Desktop\\Proyecto\\AutoCargar\\AutoCargar\\Automatizaci�n_Cargar\\DatosExcel.xls");
		   Workbook wb=Workbook.getWorkbook(src);
		  dato1= wb.getSheet(0).getCell(0, 0).getContents();
		  String dato2= wb.getSheet(0).getCell(1, 0).getContents();

		  
		 int col1=wb.getSheet(1).getRows();
		 System.out.println(col1);

			//Login
		
				WebElement usuario = driver.findElement(By.id("email"));
				usuario.sendKeys(dato1);
				WebElement contra = driver.findElement(By.id("pass"));
				contra.sendKeys(dato2);

				WebElement login = driver.findElement(By.xpath("//*[@id=\"u_0_2\"]"));
				login.click();
				driver.findElement(By.xpath("//*[@id=\"u_0_c\"]/a")).sendKeys(Keys.ESCAPE);

				Thread.sleep(1000);

				
	
				for (int i = 0; i < col1; i++) {
					
					try {
						dato3 = wb.getSheet(1).getCell(0, i).getContents();
						System.out.println(dato3);
						driver.findElement(By.cssSelector("._1frb")).sendKeys(dato3);
						driver.findElement(By.cssSelector("._1frb")).sendKeys(Keys.ENTER);
						Thread.sleep(10000);
						WebElement box = driver.findElement(By.id("contentArea"));
						names = box.findElements(By.partialLinkText(dato3));
						System.out.println("Total links: " + names.size());

						if (names.size() != 0) {
							System.out.println("el perfil " + dato3 + " existe");
						
						ArraySi.add(dato3);
						Pantallazos();
						ArchivosTxt();
						
							  
						}

						if (names.size() == 0) {
							System.out.println("el perfil " + dato3 + " no existe");
						 
						 ArrayNo.add(dato3);
						 Pantallazos();	
						 ArchivosTxt();
						
								
						}

						Thread.sleep(5000);
					} catch (Exception e) {
						e.printStackTrace();
						System.out.println(e);
					} 
					
					
				}
 
     Correo();
				}


	
	
	public static  void Pantallazos()
	{
		try{
	        
	        BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
	        
	        if (names.size() != 0) {
			ImageIO.write(image, "jpg", new File("C:/Users/maria.isabel.alzate/Desktop/Maria/FacebookAuto/Screenshots/Si/screenshot "+dato3+".jpg"));
	        }
	        else
	        {
	        	ImageIO.write(image, "jpg", new File("C:/Users/maria.isabel.alzate/Desktop/Maria/FacebookAuto/Screenshots/No/screenshot "+dato3+".jpg"));	
	        }
	    }
	    catch(Exception e){
	        e.printStackTrace();
	    }
	}
	
	public static void ArchivosTxt() throws IOException
	{
		 
		  if (names.size() != 0) {
		  File FC = new File("C:/Users/maria.isabel.alzate/Desktop/Maria/FacebookAuto/Archivos/Si/"+dato3+".txt");
		  FC.createNewFile();
		  FileWriter FW = new FileWriter("C:/Users/maria.isabel.alzate/Desktop/Maria/FacebookAuto/Archivos/Si/"+dato3+".txt");
		  BufferedWriter BW = new BufferedWriter(FW);
		  BW.write("Se inicia sesi�n en facebook con el usuario "+dato1);
		  BW.newLine();
		  BW.write("Realizo la b�squeda del perfil "+dato3+" en el buscador"); 
		  BW.newLine();
		  BW.write("Env�o correo a Adjuntando evidencias");
		  BW.close();
		  }
		  else
		  {
			  File FC = new File("C:/Users/maria.isabel.alzate/Desktop/Maria/FacebookAuto/Archivos/No/"+dato3+".txt");
			  FC.createNewFile();
			  FileWriter FW = new FileWriter("C:/Users/maria.isabel.alzate/Desktop/Maria/FacebookAuto/Archivos/No/"+dato3+".txt");
			  BufferedWriter BW = new BufferedWriter(FW);
			  BW.write("Se inicia sesi�n en facebook con el usuario "+dato1);
			  BW.newLine();
			  BW.write("Realizo la b�squeda del perfil "+dato3+" en el buscador"); 
			  BW.newLine();
			  BW.write("Env�o correo a Adjuntando evidencias");
			  BW.close();
		  }

	}
	
	public static void Correo() throws InterruptedException, EmailException
	{
		  WebDriver driver1 = new ChromeDriver();
		  driver1.get("https://www.gmail.com");
		  driver1.findElement(By.xpath("//*[@id=\"identifierId\"]")).sendKeys("mariaalzate9786@gmail.com");
		  driver1.findElement(By.xpath("//*[@id=\"identifierNext\"]/content/span")).click();
		  Thread.sleep(5000);
		  WebElement d= driver1.findElement(By.name("password"));
		  d.sendKeys("lavidaesunratico");
		  driver1.findElement(By.xpath("//*[@id=\"passwordNext\"]/content/span")).click();
		  Thread.sleep(5000);
		  driver1.findElement(By.xpath("//*[@id=\":cd\"]/div/div")).click();
		  Thread.sleep(3000);

		  Actions a = new Actions(driver1);
		  
	  for (int i = 0; i < ArraySi.size(); i++) {
			String si=ArraySi.get(i);
			
			Thread.sleep(2000);
		a.sendKeys("mariaalzate151558@correo.itm.edu.co").perform();
		    a.sendKeys(Keys.chord(Keys.TAB,Keys.TAB)).perform(); 
			a.sendKeys("Resultados "+si).perform();
			a.sendKeys(Keys.TAB).perform();
			a.sendKeys("El perfil "+si+ " existe").perform(); 			
			a.sendKeys(Keys.chord(Keys.TAB,Keys.TAB,Keys.ENTER)).perform(); 
			Thread.sleep(2000);
			StringSelection string1 = new StringSelection("C:\\Users\\maria.isabel.alzate\\Desktop\\Maria\\FacebookAuto\\Archivos\\Si\\"+si+".txt");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(string1, null);
			Thread.sleep(2000);
            RobotPegar();
            Thread.sleep(2000);
            StringSelection string2 = new StringSelection("C:\\Users\\maria.isabel.alzate\\Desktop\\Maria\\FacebookAuto\\Screenshots\\Si\\screenshot "+si+".jpg");
			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(string2, null);
			Thread.sleep(2000);
			a.sendKeys(Keys.chord(Keys.TAB,Keys.TAB,Keys.ENTER)).perform(); 
			Thread.sleep(2000);
			RobotPegar();
			Thread.sleep(2000);
			//Enviar
		     a.sendKeys(Keys.chord(Keys.CONTROL,Keys.ENTER)).perform();
			 //Nuevo correo
	         driver1.findElement(By.xpath("//*[@id=\":cd\"]/div/div")).click();
      
		  }
		  

          for (int j = 0; j < ArraySi.size(); j++) {
  			String no=ArrayNo.get(j);
  		    
  			Thread.sleep(2000);
  		    a.sendKeys("mariaalzate151558@correo.itm.edu.co").perform();
  		    a.sendKeys(Keys.chord(Keys.TAB,Keys.TAB)).perform(); 
  			a.sendKeys("Resultados "+no).perform();
  			a.sendKeys(Keys.TAB).perform();
  			a.sendKeys("El perfil "+no+ " NO existe").perform(); 			
  			a.sendKeys(Keys.chord(Keys.TAB,Keys.TAB,Keys.ENTER)).perform(); 
  			Thread.sleep(2000);
  			StringSelection string3 = new StringSelection("C:\\Users\\maria.isabel.alzate\\Desktop\\Maria\\FacebookAuto\\Archivos\\No\\"+no+".txt");
  			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(string3, null);
  			Thread.sleep(2000);
              RobotPegar();
              Thread.sleep(2000);
              StringSelection string4 = new StringSelection("C:\\Users\\maria.isabel.alzate\\Desktop\\Maria\\FacebookAuto\\Screenshots\\No\\screenshot "+no+".jpg");
  			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(string4, null);
  			Thread.sleep(2000);
  			a.sendKeys(Keys.chord(Keys.TAB,Keys.TAB,Keys.ENTER)).perform(); 
  			Thread.sleep(2000);
  			RobotPegar();
  			Thread.sleep(2000);
  			a.sendKeys(Keys.chord(Keys.CONTROL,Keys.ENTER)).perform();
        
  		  }
           
          
          Thread.sleep(5000);
           driver1.close();

	}
	
	public static void RobotPegar()
	{

		   try {
			Robot robot = new Robot();
			
			   robot.keyPress(java.awt.event.KeyEvent.VK_CONTROL);
			   robot.keyPress(java.awt.event.KeyEvent.VK_V);
			   robot.keyRelease(java.awt.event.KeyEvent.VK_V);
			   robot.keyRelease(java.awt.event.KeyEvent.VK_CONTROL);
			   robot.keyPress(java.awt.event.KeyEvent.VK_ENTER);
		       robot.keyRelease(java.awt.event.KeyEvent.VK_ENTER);
			   
		} catch (AWTException e1) {
			e1.printStackTrace();
		}
	}
	

	

	

}


