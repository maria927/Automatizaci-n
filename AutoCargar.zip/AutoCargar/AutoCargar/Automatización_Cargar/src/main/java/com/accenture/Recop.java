package com.accenture;

import java.awt.AWTException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.InputEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import javax.imageio.ImageIO;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailAttachment;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.MultiPartEmail;
import org.apache.commons.mail.SimpleEmail;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.interactions.SendKeysAction;

import jxl.Workbook;
import jxl.read.biff.BiffException;


public class Recop {

	public static void main(String[] args) throws InterruptedException {

		String exePath = "C:/Users/isabel.alzate/chromedriver_win32/chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", exePath);  
		
		
		   WebDriver driver = new ChromeDriver();
		   driver.get("http://localhost:4200/");
		   
		   //Login
		   Thread.sleep(5000);
		   driver.findElement(By.xpath("//*[@id=\"m_login\"]/div[1]/div/div[1]/div/div[2]/form/div[1]/input")).sendKeys("bancolombia@bancolombia.com");
		   driver.findElement(By.xpath("//*[@id=\"m_login\"]/div[1]/div/div[1]/div/div[2]/form/div[2]/input")).sendKeys("bancolombia");
		   driver.findElement(By.xpath("//*[@id=\"m_login_signin_submit\"]")).click();
		   
//Scroll-up
		   
		   Thread.sleep(5000);
		   driver.manage().window().maximize();
		   WebElement scroll = driver.findElement(By.xpath("//*[@id=\"SociedadesCompania\"]"));
		   scroll.sendKeys(Keys.PAGE_UP);
		   
		   //Carga
		   
		   driver.findElement(By.xpath("//*[@id=\"SociedadesCompania\"]/option[2]")).click();
		   driver.findElement(By.xpath("//*[@id=\"ValorAbsoluto\"]")).click();
		   driver.findElement(By.xpath("//*[@id=\"archivoExcel\"]")).click();
		   
			StringSelection string3 = new StringSelection("C:\\Users\\isabel.alzate\\Desktop\\Proyecto\\AutoCargar\\AutoCargar\\Automatizaci�n_Cargar\\Datos\\Consolidaci�n Planilla Operaciones Rec�procas DICIEMBRE 2017 BANCO(3).xlsx");
  			Toolkit.getDefaultToolkit().getSystemClipboard().setContents(string3, null);
  			Thread.sleep(2000);
  			RobotPegar();
  			
  			driver.findElement(By.xpath("//*[@id=\"formCarga\"]/div[2]/div[2]/button")).click();
  			
  			
		   

	}
	
	public static void RobotPegar()
	{

		   try {
			Robot robot = new Robot();
			
			   robot.keyPress(java.awt.event.KeyEvent.VK_CONTROL);
			   robot.keyPress(java.awt.event.KeyEvent.VK_V);
			   robot.keyRelease(java.awt.event.KeyEvent.VK_V);
			   robot.keyRelease(java.awt.event.KeyEvent.VK_CONTROL);
			   robot.keyPress(java.awt.event.KeyEvent.VK_ENTER);
		       robot.keyRelease(java.awt.event.KeyEvent.VK_ENTER);
			   
		} catch (AWTException e1) {
			e1.printStackTrace();
		}
	}

}
